# ПРОМПТ ДЛЯ CLAUDE CODE — БОЕВОЙ ЗАПУСК SYNERGY AUTONOMOUS
## Polygon Mainnet · 140 POL бюджет · апрель 2026

---

Вставь этот промпт в **Claude Code** (терминал, не chat).  
Предварительно: положи архив `SINERGY_FINAL_MERGED.zip` рядом.

---

```
Ты — senior Solidity/Python инженер. Выполни боевой запуск системы
SYNERGY AUTONOMOUS на Polygon Mainnet. Бюджет: 140 POL (~$59).

Архив проекта: ./SINERGY_FINAL_MERGED.zip
Распакуй его: unzip SINERGY_FINAL_MERGED.zip && cd SINERGY_FINAL_MERGED

PRIVATE_KEY уже в .env файле архива. НЕ выводи его в лог нигде.

─────────────────────────────────────────────────────────────────
КОНТЕКСТ (прочти перед началом)
─────────────────────────────────────────────────────────────────

Это DeFi система на Polygon с двумя наборами контрактов:

НАБОР A — задеплоены в deployments.json:
  SYNA:          0xb8A5D69559B3C852a82F08478503b8aFB5bfD444
  SinergiaDAO:   0x3d3f193887Ad04baE9d1d33D7613F5f22f9f0e30
  DividendWallet:0x3fE81f3BF703ebc9c3d507E4A193e83153d4296A
  SynergyBridge: 0xBe0A2dc164BD966fFC20beAFC865873E4711ec2d  ← СЛОМАН
  QuantumEasingV2:0x1EfA3Fcc5838BEb8Ef55a47dBF2aa44a078d4da1 ← СЛОМАН
  DualDEX_Engine:0xCd443617328d8bb10f7415CDD8862c13ac02d6D6
  SYNR:          0xF77e20976477dDFBB29a29AADE82083c8A01324d

НАБОР B — задеплоены в data/sinergy_master_deployed.json:
  SYNA_v2:      0x989A94067e463709A4992aDeCFCa05eA6f2d92cf
  CentralBank:  0xecD734942aF6A89B804fF5C2d0bDC294495AD9fe  ← ГЛАВНЫЙ
  SinDEX:       0x4CB7fC7b3d5bec726AaD6A5569E940C68F926d17
  SynergyCell:  0xC0AA5Bf3DA4458BeA8fF68fb7a9564CdE6008C8A
  SynergyVault: 0x32D287153766ED7240b9be7844EFC038b6e244a9
  DividendWallet_v2: 0xf108daa0BB3bdc7C8985f882A7C1d9589Bf735EF

OWNER: 0x5D9aD64322333D18B652Be9aa779B2337150f429
11 роботов в data/dao_robots_keys.json (private keys SET)

Compile artifacts: build/*.json (abi + bytecode уже готовы)
Deploy скрипт: deploy/deploy_all.py (поддерживает --dry-run)

─────────────────────────────────────────────────────────────────
ШАГ 0 — УСТАНОВКА ЗАВИСИМОСТЕЙ
─────────────────────────────────────────────────────────────────

pip install -r requirements.txt --quiet

─────────────────────────────────────────────────────────────────
ШАГ 1 — PREFLIGHT CHECK (ничего не отправляем, только читаем)
─────────────────────────────────────────────────────────────────

Запусти и покажи вывод:

  python deploy/deploy_all.py --dry-run

Затем проверь вручную через web3 (RPC: https://polygon-rpc.com):

1. OWNER баланс POL — должен быть ≥ 70 POL
2. Bridge.centralBank() — должен вернуть CentralBank (0xecD734...)
   СЕЙЧАС вернёт 0xBe0A2d... (self-loop) → это баг #1
3. Bridge.SYNA() — должен вернуть 0xb8A5...
   (в contracts/SynergyBridge.sol строка 68 уже исправлена на 0xb8A5...)
4. QE_V2.cb() или первый аргумент конструктора — должен быть CentralBank
   СЕЙЧАС вернёт 0xBe0A2d... (Bridge!) → это баг #6
5. Балансы 11 роботов — покажи каждый

Выведи итог: что сломано, что OK.

─────────────────────────────────────────────────────────────────
ШАГ 2 — РЕДЕПЛОЙ SynergyBridge (TЗ Fix #1 + #2)
─────────────────────────────────────────────────────────────────

Контракт уже исправлен в contracts/SynergyBridge.sol:
  - строка 68: SYNA = 0xb8A5... (не 0xd8Fc...)
  - конструктор принимает (cb, qe)

Задеплой новый Bridge:
  python deploy/deploy_all.py --phase bridge

Это создаст новый Bridge с:
  constructor(CentralBank_ADDR, ZERO_ADDR)
  — QE подключим после деплоя QE_V2

Запиши новый адрес Bridge → используй дальше.

─────────────────────────────────────────────────────────────────
ШАГ 3 — РЕДЕПЛОЙ QuantumEasingV2 (TЗ Fix #6)
─────────────────────────────────────────────────────────────────

Задеплой новый QE_V2:
  python deploy/deploy_all.py --phase qe

Это задеплоит с правильным порядком аргументов:
  constructor(CentralBank, SinDEX, NEW_BRIDGE, SYNA)

Запиши новый адрес QE_V2.

─────────────────────────────────────────────────────────────────
ШАГ 4 — WIRING (связка контрактов)
─────────────────────────────────────────────────────────────────

Выполни wiring транзакции (все от OWNER):

  python deploy/deploy_all.py --phase wire

Это выполнит:
  Bridge.setQE(NEW_QE_V2_ADDR)
  SYNA.setQEEngine(NEW_QE_V2_ADDR)
  Bridge.setToken(SYNA_ADDR, true, 10e18, 500000e18)
  L1_DEX.setQE(NEW_QE_V2_ADDR)  [если применимо]

После каждой TX — проверяй статус (success/revert).

─────────────────────────────────────────────────────────────────
ШАГ 5 — ПОПОЛНЕНИЕ РОБОТОВ (TЗ Fix #5)
─────────────────────────────────────────────────────────────────

Бюджет: 5 POL × 11 роботов = 55 POL (минимум для ~500 шагов)

  python deploy/replenish_robots.py --target 5 --dry-run

Проверь вывод — покажи сколько каждый получит.
Затем выполни реально:

  python deploy/replenish_robots.py --target 5

Жди подтверждения каждой транзакции. Покажи итоговые балансы.

─────────────────────────────────────────────────────────────────
ШАГ 6 — L1 НОДА: ДОБАВИТЬ MINING REWARD (TЗ Fix #3)
─────────────────────────────────────────────────────────────────

Уже исправлено в l1/node.py:
  - BLOCK_REWARD = 0.001 wPOL (строка 81)
  - mine_block() вызывает ledger.credit(OWNER, BLOCK_REWARD, 'wPOL') (строка 206)

Проверь что исправление на месте:

  grep -n "BLOCK_REWARD\|ledger.credit" l1/node.py

Должно показать строки 81 и 206.

─────────────────────────────────────────────────────────────────
ШАГ 7 — L1 НОДА: ОТКАЛИБРОВАТЬ SINDEX (TЗ Fix #4)
─────────────────────────────────────────────────────────────────

Уже исправлено в l1/sinergy_dex.py:
  - начальный пул wSYNA/wPOL: P ≈ 0.01404 (не 0.00002)

Проверь:
  grep -n "L1_SYNA_INIT\|L1_WPOL_INIT\|P0" l1/sinergy_dex.py | head -5

Должно показать L1_WPOL_INIT = 5.0 и P0 = 9.905/705.58

─────────────────────────────────────────────────────────────────
ШАГ 8 — PW1-PW10 В DAO (TЗ v2.0 Fix #8)
─────────────────────────────────────────────────────────────────

Файл setup_pw_in_dao.py уже в корне проекта.

Сначала dry-run:
  python setup_pw_in_dao.py

Покажи список транзакций (должно быть 21 TX).
Затем выполни (нужен PRIVATE_KEY в env):
  PRIVATE_KEY=$(grep PK .env | cut -d= -f2) python setup_pw_in_dao.py

Ожидаемый результат: каждый PW1-PW10 становится участником
SynergyCell с 9 CELL токенами. NetworkConfig: memberYieldPct=25%.

─────────────────────────────────────────────────────────────────
ШАГ 9 — ФИНАЛЬНАЯ ПРОВЕРКА
─────────────────────────────────────────────────────────────────

Запусти bootstrap в режиме проверки:
  python bootstrap.py --check-only

Он проверит:
  ✓ Балансы роботов >= 5 POL
  ✓ Bridge.centralBank() == CentralBank
  ✓ Bridge.SYNA() == 0xb8A5...
  ✓ QE_V2 деплоен с правильным CB
  ✓ SynergyCell.isMember(PW1) == true

Покажи полный вывод. Все пункты должны быть ✓.

─────────────────────────────────────────────────────────────────
ШАГ 10 — ЗАПУСК СИСТЕМЫ
─────────────────────────────────────────────────────────────────

Только после ✓ всех проверок:

1. Запусти L1 ноду в фоне:
   python l1/node.py --mine &
   L1_PID=$!

2. Запусти L1 Keeper в фоне:
   python -c "
   from autonomous.l1_keeper import L1Keeper
   import time
   k = L1Keeper()
   k.run()
   while True: time.sleep(60)
   " &

3. Подожди 30 секунд, проверь L1:
   curl http://localhost:5050/status | python -m json.tool
   curl http://localhost:5050/balance | python -m json.tool

4. Запусти основной оркестратор:
   python bootstrap.py

─────────────────────────────────────────────────────────────────
ШАГ 11 — МОНИТОРИНГ ПЕРВЫХ 2 ЧАСОВ
─────────────────────────────────────────────────────────────────

Каждые 30 минут выводи статус:

  python deploy/inventory.py

Покажи:
  - POL баланс OWNER
  - Балансы роботов
  - L1 wPOL баланс (curl localhost:5050/balance)
  - SinergiaDAO.sotaStepCount()
  - SYNA totalSupply (должен снижаться — демерредж)
  - SynergyCell.netProfit()

─────────────────────────────────────────────────────────────────
ВАЖНЫЕ ОГРАНИЧЕНИЯ
─────────────────────────────────────────────────────────────────

1. НИКОГДА не выводи private key в лог или stdout
2. При любом revert — СТОП. Покажи ошибку, жди инструкций.
3. Не трогай contracts_master/ — это отдельный набор
4. deploy/deploy_all.py сохраняет state в deployments.json —
   если шаг упал, можно запустить повторно, он пропустит готовое
5. Если OWNER баланс упал ниже 20 POL — СТОП немедленно
6. L1 нода работает локально (SQLite) — данные в l1/sinergy_l1.db

─────────────────────────────────────────────────────────────────
ОЖИДАЕМЫЙ РЕЗУЛЬТАТ ЧЕРЕЗ 24 ЧАСА
─────────────────────────────────────────────────────────────────

  L1 mining:      ~43 POL/день (wPOL → bridge_out → POL)
  SinDEX арб:     ~7 POL/день
  Газ расходы:    ~38 POL/день
  Net P&L:        ~+12 POL/день (+$5.31)
  PW1 дивиденды:  ~$0.95/день (через SynergyCell.claimEqualBonus)

Если через 2 часа:
  - роботы работают (sotaStepCount растёт) ✓
  - L1 блоки майнятся (localhost:5050/status) ✓
  - SYNA supply снижается (burnPerBlock работает) ✓
  → система запущена успешно.
```

---

## Дополнительные команды для Claude Code

```bash
# Проверить конкретный контракт on-chain
python -c "
from web3 import Web3
w3 = Web3(Web3.HTTPProvider('https://polygon-rpc.com'))
import json

# Bridge centralBank
bridge_abi = json.load(open('build/SynergyBridge.json'))['abi']
bridge = w3.eth.contract(
    address='0xBe0A2dc164BD966fFC20beAFC865873E4711ec2d',
    abi=bridge_abi
)
print('Bridge.centralBank:', bridge.functions.centralBank().call())
print('Bridge.SYNA:', bridge.functions.SYNA().call())
"

# Проверить балансы роботов
python -c "
from web3 import Web3
import json
w3 = Web3(Web3.HTTPProvider('https://polygon-rpc.com'))
robots = json.load(open('data/dao_robots_keys.json'))
for r in robots:
    bal = w3.eth.get_balance(r['address']) / 1e18
    print(f'{r[\"role\"]:12} {r[\"address\"][:16]}... {bal:.4f} POL')
"

# Посмотреть текущий gas price
python -c "
from web3 import Web3
w3 = Web3(Web3.HTTPProvider('https://polygon-rpc.com'))
gwei = w3.eth.gas_price / 1e9
print(f'Gas price: {gwei:.1f} gwei')
print(f'Status: {\"OK запускаем\" if gwei < 100 else \"ЖДЁМ дешевле\" if gwei < 150 else \"СТОП дорого\"}')
"
```

---

## Что делать если что-то пошло не так

**Bridge deploy упал с revert:**
```bash
# Проверить код ошибки
python -c "
from web3 import Web3
w3 = Web3(Web3.HTTPProvider('https://polygon-rpc.com'))
# Вставить hash транзакции из ошибки
rcpt = w3.eth.get_transaction_receipt('0x...')
print('status:', rcpt.status)
print('gasUsed:', rcpt.gasUsed)
"
```

**Роботы не пополняются:**  
Проверь что `data/dao_robots_keys.json` существует и все `private_key` заполнены.

**L1 нода не стартует:**  
```bash
python l1/node.py --status  # только статус без майнинга
```

**SOTA не идёт (stepCount не растёт):**  
Роботы должны иметь баланс ≥ 0.01 POL + газ. Проверить:
```bash
python deploy/replenish_robots.py --target 5 --dry-run
```

---

*Сгенерировано: SYNERGY AUTONOMOUS · Shtenco AI · апрель 2026*
*Архив: SINERGY_FINAL_MERGED.zip · OWNER: 0x5D9aD...*
