# SYNERGY historical import — 2026-09

Direct code/docs/config artifacts: **1**.
External evidence pending due connector binary/large-artifact limits: **0**.
Total mapped: **1**.

See `IMPORT_MANIFEST.json` for exact SHA-256 and provenance. Import does not promote R&D/LEGACY to CANONICAL.
